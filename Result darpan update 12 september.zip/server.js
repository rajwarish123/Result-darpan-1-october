const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = path.join(__dirname, 'data');
const USERS_PATH = path.join(DATA_DIR, 'users.json');
const MESSAGES_PATH = path.join(DATA_DIR, 'messages.json');
const CONTACTS_PATH = path.join(DATA_DIR, 'contacts.json');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin === 'http://127.0.0.1:3000' || origin === 'http://localhost:3000') {
    res.set('Access-Control-Allow-Origin', origin);
  }
  next();
});

const staticDir = __dirname;
app.use(express.static(staticDir));

function ensureStore() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(USERS_PATH)) {
    fs.writeFileSync(USERS_PATH, JSON.stringify([], null, 2));
  }

  if (!fs.existsSync(MESSAGES_PATH)) {
    fs.writeFileSync(MESSAGES_PATH, JSON.stringify([
      { id: 1, author: 'mentor', text: 'Welcome to the SSC CGL study room. Ask your first question!', createdAt: new Date().toISOString() },
      { id: 2, author: 'mentor', text: 'Tip: revise arithmetic shortcuts daily for faster accuracy.', createdAt: new Date().toISOString() }
    ], null, 2));
  }

  if (!fs.existsSync(CONTACTS_PATH)) {
    fs.writeFileSync(CONTACTS_PATH, JSON.stringify([], null, 2));
  }
}

function readJson(filePath, fallback) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch (error) {
    return fallback;
  }
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function numberOptions(answer, step = 1) {
  return [answer, answer + step, answer + (step * 2), Math.max(0, answer - step)];
}

function createGeneratedQuestion(exam, index) {
  const variant = index % 10;
  const number = index + 1;
  const sourceUrl = exam === 'SSC CGL'
    ? 'https://ssc.gov.in/for-candidates/previous-year-question-paper'
    : exam === 'Railway NTPC'
      ? 'https://www.adda247.com/jobs/rrb-ntpc-previous-year-question-paper/'
      : 'https://www.adda247.com/jobs/rrb-group-d-previous-year-papers/';

  if (variant === 0) {
    const base = 200 + ((number * 7) % 20) * 10;
    const rate = 5 + (number % 4) * 5;
    const answer = (base * rate) / 100;
    return { exam, year: 'Pattern practice', topic: 'Quantitative Aptitude', text: `What is ${rate}% of ${base}?`, options: numberOptions(answer, 10), answer: 0, sourceUrl };
  }
  if (variant === 1) {
    const first = 12 + (number % 8);
    const answer = first + 6;
    return { exam, year: 'Pattern practice', topic: 'Mathematics', text: `The average of ${first}, ${first + 6}, and ${first + 12} is:`, options: numberOptions(answer, 3), answer: 0, sourceUrl };
  }
  if (variant === 2) {
    const speed = 30 + (number % 5) * 10;
    const time = 2 + (number % 4);
    const answer = speed * time;
    return { exam, year: 'Pattern practice', topic: 'Time, Speed and Distance', text: `A vehicle travels at ${speed} km/h for ${time} hours. How far does it travel?`, options: numberOptions(answer, 10), answer: 0, sourceUrl };
  }
  if (variant === 3) {
    const principal = 1000 + (number % 10) * 500;
    const answer = principal * 8 * 2 / 100;
    return { exam, year: 'Pattern practice', topic: 'Simple Interest', text: `What is the simple interest on Rs ${principal} at 8% per annum for 2 years?`, options: numberOptions(answer, 100), answer: 0, sourceUrl };
  }
  if (variant === 4) {
    const answer = 3 + (number % 7);
    return { exam, year: 'Pattern practice', topic: 'Number Series', text: `Find the next number: ${answer - 1}, ${answer + 1}, ${answer + 3}, ${answer + 5}, ?`, options: [answer + 7, answer + 5, answer + 9, answer + 3], answer: 0, sourceUrl };
  }
  if (variant === 5) {
    const facts = [
      ['Which gas is essential for human respiration?', ['Nitrogen', 'Oxygen', 'Hydrogen', 'Helium'], 1],
      ['Which is the largest ocean on Earth?', ['Atlantic Ocean', 'Indian Ocean', 'Pacific Ocean', 'Arctic Ocean'], 2],
      ['Which organ pumps blood through the human body?', ['Lungs', 'Heart', 'Kidneys', 'Liver'], 1],
      ['Which is the first month of the calendar year?', ['March', 'January', 'June', 'April'], 1]
    ];
    const fact = facts[number % facts.length];
    return { exam, year: 'Pattern practice', topic: 'General Awareness', text: fact[0], options: fact[1], answer: fact[2], sourceUrl };
  }
  if (variant === 6) {
    const facts = [
      ['The Constitution of India came into effect on:', ['15 August 1947', '26 January 1950', '26 November 1949', '2 October 1950'], 1],
      ['Which planet is known as the Red Planet?', ['Venus', 'Mars', 'Jupiter', 'Mercury'], 1],
      ['How many sides does a hexagon have?', ['Five', 'Six', 'Seven', 'Eight'], 1],
      ['Which instrument measures temperature?', ['Barometer', 'Thermometer', 'Ammeter', 'Compass'], 1]
    ];
    const fact = facts[number % facts.length];
    return { exam, year: 'Pattern practice', topic: exam === 'SSC CGL' ? 'General Awareness' : 'General Science', text: fact[0], options: fact[1], answer: fact[2], sourceUrl };
  }
  if (variant === 7) {
    const code = String.fromCharCode(65 + (number % 20));
    const next = String.fromCharCode(code.charCodeAt(0) + 1);
    return { exam, year: 'Pattern practice', topic: 'Reasoning', text: `If ${code} is coded as ${next}, how is the next letter coded?`, options: [String.fromCharCode(next.charCodeAt(0) + 1), code, next, String.fromCharCode(next.charCodeAt(0) + 2)], answer: 0, sourceUrl };
  }
  if (variant === 8) {
    const length = 40 + (number % 6) * 10;
    const breadth = 5 + (number % 4) * 5;
    const answer = length * breadth;
    return { exam, year: 'Pattern practice', topic: 'Mensuration', text: `What is the area of a rectangle with length ${length} cm and breadth ${breadth} cm?`, options: numberOptions(answer, 50), answer: 0, sourceUrl };
  }
  const answer = 10 + (number % 9);
  return { exam, year: 'Pattern practice', topic: 'English and Vocabulary', text: 'Choose the word closest in meaning to "rapid".', options: ['Slow', 'Quick', 'Quiet', 'Late'], answer: 1, sourceUrl };
}

function getQuestionBank() {
  const curatedQuestions = readJson(path.join(DATA_DIR, 'previous-year-questions.json'), []);
  const exams = ['SSC CGL', 'Railway NTPC', 'Railway Group D'];
  const generatedQuestions = Array.from({ length: 500 }, (_, index) => createGeneratedQuestion(exams[index % exams.length], index));
  return curatedQuestions.concat(generatedQuestions);
}

const questionSetSubjects = {
  'SSC CGL': ['English', 'Mathematics', 'Reasoning', 'General Awareness', 'Indian Polity'],
  'Railway NTPC': ['Mathematics', 'Reasoning', 'General Awareness', 'General Science', 'Indian Polity'],
  'Railway Group D': ['Mathematics', 'Reasoning', 'General Awareness', 'General Science', 'Indian Polity']
};

function getQuestionSet(exam, subject, setNumber) {
  const subjects = questionSetSubjects[exam] || [];
  const safeSubject = subjects.includes(subject) ? subject : subjects[0];
  const safeSet = Math.min(50, Math.max(1, Number(setNumber) || 1));
  const sourceUrl = exam === 'SSC CGL'
    ? 'https://ssc.gov.in/for-candidates/previous-year-question-paper'
    : exam === 'Railway NTPC'
      ? 'https://www.adda247.com/jobs/rrb-ntpc-previous-year-question-paper/'
      : 'https://www.adda247.com/jobs/rrb-group-d-previous-year-papers/';
  const ncertUrl = 'https://ncert.nic.in/textbook.php';

  return Array.from({ length: 50 }, (_, index) => {
    const number = ((safeSet - 1) * 50) + index + 1;
    const variation = number % 10;
    let question;

    if (safeSubject === 'Mathematics') {
      const base = 120 + ((number * 13) % 30) * 10;
      const rate = 5 + (number % 6) * 5;
      const answer = (base * rate) / 100;
      question = { text: `What is ${rate}% of ${base}?`, options: numberOptions(answer, 10), answer: 0, topic: 'Percentages' };
    } else if (safeSubject === 'Reasoning') {
      const answer = 3 + (number % 12);
      question = { text: `Find the next number: ${answer - 1}, ${answer + 1}, ${answer + 3}, ${answer + 5}, ?`, options: [answer + 7, answer + 5, answer + 9, answer + 3], answer: 0, topic: 'Number Series' };
    } else if (safeSubject === 'English') {
      const words = [['rapid', ['Slow', 'Quick', 'Quiet', 'Late'], 1], ['ancient', ['Modern', 'Old', 'Large', 'Bright'], 0], ['brief', ['Short', 'Heavy', 'Clear', 'Wide'], 0], ['honest', ['Truthful', 'Angry', 'Careless', 'Silent'], 0]];
      const word = words[variation % words.length];
      question = { text: `Choose the word closest in meaning to '${word[0]}'.`, options: word[1], answer: word[2], topic: 'Vocabulary' };
    } else if (safeSubject === 'General Science') {
      const facts = [
        ['Which gas is essential for human respiration?', ['Nitrogen', 'Oxygen', 'Hydrogen', 'Helium'], 1, 'Biology'],
        ['Which vitamin is produced in skin exposed to sunlight?', ['Vitamin A', 'Vitamin B12', 'Vitamin C', 'Vitamin D'], 3, 'Nutrition'],
        ['What is the SI unit of force?', ['Joule', 'Watt', 'Newton', 'Pascal'], 2, 'Physics'],
        ['Which process helps green plants make food?', ['Respiration', 'Photosynthesis', 'Digestion', 'Filtration'], 1, 'Biology']
      ];
      const fact = facts[variation % facts.length];
      question = { text: fact[0], options: fact[1], answer: fact[2], topic: fact[3] };
    } else if (safeSubject === 'Indian Polity') {
      const facts = [
        ['Who is the constitutional head of the Union executive in India?', ['Prime Minister', 'President', 'Chief Justice', 'Speaker'], 1, 'Union Executive'],
        ['A Money Bill can be introduced only in the:', ['Rajya Sabha', 'Lok Sabha', 'State Legislative Council', 'Supreme Court'], 1, 'Parliament'],
        ['Which body conducts elections to Parliament and state legislatures?', ['Union Public Service Commission', 'Election Commission of India', 'Finance Commission', 'NITI Aayog'], 1, 'Elections'],
        ['The minimum age for membership of the Lok Sabha is:', ['18 years', '21 years', '25 years', '30 years'], 2, 'Parliament'],
        ['Who appoints the Comptroller and Auditor General of India?', ['Prime Minister', 'President', 'Chief Justice', 'Lok Sabha Speaker'], 1, 'Constitutional Offices'],
        ['Which part of the Constitution contains Fundamental Rights?', ['Part II', 'Part III', 'Part IV', 'Part V'], 1, 'Fundamental Rights'],
        ['The 73rd Constitutional Amendment is associated with:', ['Municipalities', 'Panchayati Raj', 'Emergency provisions', 'Fundamental Duties'], 1, 'Local Government'],
        ['The Council of Ministers is collectively responsible to the:', ['Rajya Sabha', 'Lok Sabha', 'President', 'Supreme Court'], 1, 'Union Executive'],
        ['Who presides over a joint sitting of both Houses of Parliament?', ['President', 'Vice-President', 'Lok Sabha Speaker', 'Prime Minister'], 2, 'Parliament'],
        ['The Directive Principles of State Policy are included in:', ['Part III', 'Part IV', 'Part V', 'Part VI'], 1, 'Constitution']
      ];
      const fact = facts[variation % facts.length];
      question = { text: fact[0], options: fact[1], answer: fact[2], topic: fact[3] };
    } else {
      const facts = [
        ['Which Article is associated with the Right to Constitutional Remedies?', ['Article 14', 'Article 19', 'Article 21', 'Article 32'], 3, 'Indian Polity'],
        ['Which is the largest ocean on Earth?', ['Atlantic Ocean', 'Indian Ocean', 'Pacific Ocean', 'Arctic Ocean'], 2, 'Geography'],
        ['The first passenger train in India ran between Bori Bunder and:', ['Thane', 'Pune', 'Surat', 'Nagpur'], 0, 'Railway History'],
        ['Who appoints the Governor of an Indian state?', ['Prime Minister', 'President', 'Chief Minister', 'Parliament'], 1, 'Indian Polity']
      ];
      const fact = facts[variation % facts.length];
      question = { text: fact[0], options: fact[1], answer: fact[2], topic: fact[3] };
    }

    return { id: `${exam}-${safeSubject}-${safeSet}-${index + 1}`, exam, subject: safeSubject, set: safeSet, year: 'Pattern practice', ...question, sourceUrl, ncertUrl };
  });
}

ensureStore();

const users = readJson(USERS_PATH, []);
const messages = readJson(MESSAGES_PATH, []);
const contacts = readJson(CONTACTS_PATH, []);
const chatClients = new Set();

function persistUsers() {
  writeJson(USERS_PATH, users);
}

function persistMessages() {
  writeJson(MESSAGES_PATH, messages);
}

function persistContacts() {
  writeJson(CONTACTS_PATH, contacts);
}

function getUserStats(user) {
  const testAttempts = Array.isArray(user.testAttempts) ? user.testAttempts : [];
  const totalAccuracy = testAttempts.reduce((sum, attempt) => sum + attempt.accuracy, 0);
  const studyTimeSeconds = testAttempts.reduce((sum, attempt) => sum + (attempt.durationSeconds || 0), 0);

  return {
    testsTaken: testAttempts.length,
    bestAccuracy: testAttempts.length ? Math.max(...testAttempts.map((attempt) => attempt.accuracy)) : 0,
    averageAccuracy: testAttempts.length ? Math.round(totalAccuracy / testAttempts.length) : 0,
    studyTimeSeconds,
    studyTimeMinutes: Math.round(studyTimeSeconds / 60),
    testAttempts
  };
}

function broadcastProfileUpdate(user) {
  const payload = JSON.stringify({ email: user.email, stats: getUserStats(user) });
  for (const client of chatClients) {
    client.write(`event: profile-updated\ndata: ${payload}\n\n`);
  }
}

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Result Darpan backend is running.' });
});

app.get('/api/questions', (req, res) => {
  res.json({ questions: getQuestionBank() });
});

app.get('/api/question-sets', (req, res) => {
  const exam = questionSetSubjects[req.query.exam] ? req.query.exam : 'SSC CGL';
  const subjects = questionSetSubjects[exam];
  const subject = subjects.includes(req.query.subject) ? req.query.subject : subjects[0];
  const set = Math.min(50, Math.max(1, Number(req.query.set) || 1));
  res.json({ exam, subject, set, totalSets: 50, subjects, questions: getQuestionSet(exam, subject, set) });
});

app.post('/api/contact', (req, res) => {
  const { name, email, subject, message } = req.body || {};
  const contactName = typeof name === 'string' ? name.trim() : '';
  const contactEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
  const contactSubject = typeof subject === 'string' ? subject.trim() : '';
  const contactMessage = typeof message === 'string' ? message.trim() : '';

  if (!contactName || !contactEmail || !contactMessage) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }

  if (!/^\S+@\S+\.\S+$/.test(contactEmail)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  contacts.push({
    id: Date.now(),
    name: contactName,
    email: contactEmail,
    subject: contactSubject || 'General enquiry',
    message: contactMessage,
    createdAt: new Date().toISOString()
  });
  persistContacts();
  res.status(201).json({ message: 'Thanks for reaching out. We will get back to you soon.' });
});

app.get('/api/chat/messages', (req, res) => {
  res.json({ messages });
});

app.get('/api/chat/stream', (req, res) => {
  res.set({
    'Cache-Control': 'no-cache',
    'Content-Type': 'text/event-stream',
    Connection: 'keep-alive'
  });
  res.flushHeaders();
  res.write(': connected\n\n');
  chatClients.add(res);

  req.on('close', () => chatClients.delete(res));
});

app.post('/api/chat/messages', (req, res) => {
  const { text, author = 'student', email = '' } = req.body || {};
  const messageText = typeof text === 'string' ? text.trim() : '';

  if (!messageText) {
    return res.status(400).json({ error: 'Message text is required.' });
  }

  const blockedWords = ['idiot', 'stupid', 'shut up', 'hate', 'kill yourself'];
  const normalized = ` ${messageText.toLowerCase()} `;
  const hasBlockedWord = blockedWords.some((word) => normalized.includes(word));

  if (hasBlockedWord) {
    return res.status(400).json({
      error: 'Your message violates the study room rules. Please keep the chat respectful.'
    });
  }

  const newMessage = {
    id: Date.now(),
    author,
    email: typeof email === 'string' ? email.trim().toLowerCase() : '',
    text: messageText,
    createdAt: new Date().toISOString()
  };

  messages.push(newMessage);
  persistMessages();
  for (const client of chatClients) {
    client.write(`event: message\ndata: ${JSON.stringify(newMessage)}\n\n`);
  }
  res.status(201).json({ message: newMessage });
});

app.post('/api/auth/signup', (req, res) => {
  const { name, email, password, exam, location } = req.body || {};

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  const existingUser = users.find((user) => user.email.toLowerCase() === String(email).toLowerCase());
  if (existingUser) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  const user = {
    id: Date.now(),
    name: String(name).trim(),
    email: String(email).trim().toLowerCase(),
    password: String(password),
    exam: String(exam || 'SSC CGL').trim(),
    location: String(location || 'India').trim(),
    testAttempts: []
  };

  users.push(user);
  persistUsers();
  res.status(201).json({
    message: 'Account created successfully.',
    user: { id: user.id, name: user.name, email: user.email, exam: user.exam, location: user.location }
  });
});

app.post('/api/auth/guest', (req, res) => {
  const { name, exam, location } = req.body || {};
  const guestId = `GUEST-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

  if (!String(name || '').trim() || !String(exam || '').trim() || !String(location || '').trim()) {
    return res.status(400).json({ error: 'Name, exam, and location are required for guest access.' });
  }

  const user = {
    id: guestId,
    guestId,
    isGuest: true,
    name: String(name).trim(),
    email: `${guestId.toLowerCase()}@guest.resultdarpan.local`,
    exam: String(exam).trim(),
    location: String(location).trim(),
    testAttempts: []
  };

  users.push(user);
  persistUsers();
  res.status(201).json({
    message: 'Guest profile created.',
    guestId,
    user: { id: user.id, guestId, isGuest: true, name: user.name, email: user.email, exam: user.exam, location: user.location }
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = users.find((entry) => entry.email.toLowerCase() === String(email).trim().toLowerCase());
  if (!user || user.password !== String(password)) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  res.json({
    message: 'Login successful.',
    user: { id: user.id, guestId: user.guestId || null, isGuest: Boolean(user.isGuest), name: user.name, email: user.email, exam: user.exam, location: user.location }
  });
});

app.post('/api/auth/reset-password', (req, res) => {
  const { email, otp, newPassword } = req.body || {};

  if (!email || !otp || !newPassword) {
    return res.status(400).json({ error: 'Email, OTP, and a new password are required.' });
  }

  const user = users.find((entry) => entry.email.toLowerCase() === String(email).trim().toLowerCase());
  if (!user) {
    return res.status(404).json({ error: 'Account not found.' });
  }

  if (String(otp).trim() !== '123456') {
    return res.status(400).json({ error: 'The OTP is incorrect.' });
  }

  if (String(newPassword).length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
  }

  user.password = String(newPassword);
  persistUsers();
  res.json({ message: 'Password updated successfully.' });
});

app.get('/api/profile/:email', (req, res) => {
  const email = String(req.params.email).trim().toLowerCase();
  const user = users.find((entry) => entry.email.toLowerCase() === email);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const stats = getUserStats(user);

  res.json({
    user: { id: user.id, guestId: user.guestId || null, isGuest: Boolean(user.isGuest), name: user.name, email: user.email, exam: user.exam, location: user.location },
    stats: {
      messagesSent: messages.filter((message) => message.email === email).length,
      ...stats
    }
  });
});

app.post('/api/profile/:email/test-results', (req, res) => {
  const email = String(req.params.email).trim().toLowerCase();
  const user = users.find((entry) => entry.email.toLowerCase() === email);
  const score = Number(req.body?.score);
  const total = Number(req.body?.total);
  const durationSeconds = Number(req.body?.durationSeconds || 0);

  if (!user) return res.status(404).json({ error: 'User not found.' });
  if (!Number.isInteger(score) || !Number.isInteger(total) || total <= 0 || score < 0 || score > total) {
    return res.status(400).json({ error: 'A valid test score is required.' });
  }
  if (!Number.isInteger(durationSeconds) || durationSeconds < 0 || durationSeconds > 86400) {
    return res.status(400).json({ error: 'A valid study duration is required.' });
  }

  if (!Array.isArray(user.testAttempts)) user.testAttempts = [];
  const attempt = {
    id: Date.now(),
    score,
    total,
    accuracy: Math.round((score / total) * 100),
    durationSeconds,
    createdAt: new Date().toISOString()
  };
  user.testAttempts.push(attempt);
  persistUsers();
  broadcastProfileUpdate(user);

  const stats = getUserStats(user);

  res.status(201).json({
    attempt,
    stats
  });
});

app.get('/api/admin/summary', (req, res) => {
  const totalUsers = users.length;
  const totalMessages = messages.length;
  const mentorMessages = messages.filter((message) => message.author === 'mentor').length;
  const studentMessages = messages.filter((message) => message.author === 'student').length;
  const recentUsers = [...users].slice(-5).reverse().map((user) => ({
    id: user.id,
    name: user.name,
    email: user.email,
    exam: user.exam,
    location: user.location
  }));
  const recentMessages = [...messages].slice(-8).reverse().map((message) => ({
    id: message.id,
    author: message.author,
    text: message.text,
    createdAt: message.createdAt
  }));

  res.json({
    totalUsers,
    totalMessages,
    mentorMessages,
    studentMessages,
    recentUsers,
    recentMessages,
    generatedAt: new Date().toISOString()
  });
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(staticDir, 'admin.html'));
});

app.use((req, res) => {
  res.sendFile(path.join(staticDir, 'index.html'));
});

if (require.main === module) {
  app.listen(PORT, HOST, () => {
    console.log(`Result Darpan backend listening on http://${HOST}:${PORT}`);
  });
}

module.exports = app;
