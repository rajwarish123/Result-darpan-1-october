const test = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');

const app = require('./server');

test('GET /api/health returns ok', async () => {
  const response = await request(app).get('/api/health');
  assert.equal(response.status, 200);
  assert.equal(response.body.status, 'ok');
});

test('GET /api/questions returns the full multi-exam question bank', async () => {
  const response = await request(app).get('/api/questions');
  assert.equal(response.status, 200);
  assert.equal(response.body.questions.length, 518);
  assert.deepEqual(new Set(response.body.questions.map((question) => question.exam)), new Set(['SSC CGL', 'Railway NTPC', 'Railway Group D']));
});

test('POST /api/contact stores a contact message', async () => {
  const response = await request(app).post('/api/contact').send({
    name: 'Website Visitor',
    email: `visitor-${Date.now()}@example.com`,
    subject: 'Help with mock tests',
    message: 'I have a question about the practice tests.'
  });

  assert.equal(response.status, 201);
  assert.match(response.body.message, /get back to you/i);
});

test('POST /api/auth/signup creates a user', async () => {
  const uniqueEmail = `testuser-${Date.now()}@example.com`;
  const response = await request(app).post('/api/auth/signup').send({
    name: 'Test User',
    email: uniqueEmail,
    password: 'secret123',
    exam: 'UPSC',
    location: 'Delhi'
  });

  assert.equal(response.status, 201);
  assert.equal(response.body.user.email, uniqueEmail);
});

test('POST /api/auth/guest creates a unique guest profile', async () => {
  const first = await request(app).post('/api/auth/guest').send({
    name: 'Guest Learner', exam: 'SSC CGL', location: 'Jaipur'
  });
  const second = await request(app).post('/api/auth/guest').send({
    name: 'Another Guest', exam: 'UPSC', location: 'Kochi'
  });

  assert.equal(first.status, 201);
  assert.equal(second.status, 201);
  assert.match(first.body.guestId, /^GUEST-/);
  assert.notEqual(first.body.guestId, second.body.guestId);
  assert.equal(first.body.user.isGuest, true);
  assert.equal(first.body.user.exam, 'SSC CGL');
});

test('GET /api/admin/summary returns dashboard stats', async () => {
  const response = await request(app).get('/api/admin/summary');
  assert.equal(response.status, 200);
  assert.equal(typeof response.body.totalUsers, 'number');
  assert.equal(typeof response.body.totalMessages, 'number');
  assert.ok(Array.isArray(response.body.recentUsers));
  assert.ok(Array.isArray(response.body.recentMessages));
});

test('GET /api/profile/:email returns that user profile and activity', async () => {
  const email = `profile-${Date.now()}@example.com`;
  await request(app).post('/api/auth/signup').send({
    name: 'Profile User', email, password: 'secret123', exam: 'CAT', location: 'Pune'
  });
  await request(app).post('/api/chat/messages').send({
    text: 'My account message', author: 'student', email
  });

  const response = await request(app).get(`/api/profile/${encodeURIComponent(email)}`);
  assert.equal(response.status, 200);
  assert.equal(response.body.user.email, email);
  assert.equal(response.body.user.exam, 'CAT');
  assert.equal(response.body.stats.messagesSent, 1);
});

test('POST /api/profile/:email/test-results updates user test stats', async () => {
  const email = `results-${Date.now()}@example.com`;
  await request(app).post('/api/auth/signup').send({
    name: 'Results User', email, password: 'secret123', exam: 'SSC', location: 'Patna'
  });

  const saveResponse = await request(app).post(`/api/profile/${encodeURIComponent(email)}/test-results`).send({ score: 8, total: 10, durationSeconds: 120 });
  assert.equal(saveResponse.status, 201);
  assert.equal(saveResponse.body.stats.testsTaken, 1);
  assert.equal(saveResponse.body.stats.bestAccuracy, 80);
  assert.equal(saveResponse.body.stats.averageAccuracy, 80);
  assert.equal(saveResponse.body.stats.studyTimeMinutes, 2);
  assert.equal(saveResponse.body.attempt.durationSeconds, 120);

  const profileResponse = await request(app).get(`/api/profile/${encodeURIComponent(email)}`);
  assert.equal(profileResponse.body.stats.testsTaken, 1);
  assert.equal(profileResponse.body.stats.bestAccuracy, 80);
  assert.equal(profileResponse.body.stats.studyTimeMinutes, 2);
});

test('POST /api/chat/messages rejects abusive content', async () => {
  const response = await request(app).post('/api/chat/messages').send({ text: 'you are stupid' });
  assert.equal(response.status, 400);
  assert.match(response.body.error, /study room rules/i);
});
