const pageThemeToggles = document.querySelectorAll('.theme-toggle');
function applyPageTheme(theme) {
  const dark = theme === 'dark';
  document.body.classList.toggle('dark-theme', dark);
  pageThemeToggles.forEach((button) => {
    button.setAttribute('aria-pressed', String(dark));
    button.setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
  });
  localStorage.setItem('preply-theme', theme);
}
applyPageTheme(localStorage.getItem('preply-theme') || 'light');
pageThemeToggles.forEach((button) => button.addEventListener('click', () => applyPageTheme(document.body.classList.contains('dark-theme') ? 'light' : 'dark')));

const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');
mainNav?.querySelectorAll(':scope > a').forEach((link) => {
  if (link.textContent.trim().toLowerCase() === 'admin dashboard') link.remove();
});
const keepNavLabels = new Set(['my profile', 'contact us', 'about us', 'test series', 'previous year questions', 'chat with mentor']);
if (mainNav && !mainNav.querySelector('.more-menu')) {
  const existingNavLabels = new Set([...mainNav.querySelectorAll(':scope > a')].map((link) => link.textContent.replace('↗', '').trim().toLowerCase()));
  [['Contact us', 'contact.html'], ['About us', 'index.html#stats']].forEach(([label, href]) => {
    if (!existingNavLabels.has(label.toLowerCase())) {
      const link = document.createElement('a');
      link.href = href;
      link.textContent = label;
      mainNav.appendChild(link);
    }
  });
  if (!mainNav.querySelector('a[href="previous-year-questions.html"]')) {
    const link = document.createElement('a');
    link.href = 'previous-year-questions.html';
    link.textContent = 'Previous year questions';
    mainNav.appendChild(link);
  }
  const movedNavLinks = [...mainNav.querySelectorAll(':scope > a')].filter((link) => !keepNavLabels.has(link.textContent.replace('↗', '').trim().toLowerCase()));
  if (movedNavLinks.length) {
    const moreMenu = document.createElement('div');
    moreMenu.className = 'more-menu';
    moreMenu.innerHTML = '<button class="more-toggle" type="button" aria-expanded="false">More <span>⌄</span></button><div class="more-dropdown"></div>';
    const dropdown = moreMenu.querySelector('.more-dropdown');
    movedNavLinks.forEach((link) => dropdown.appendChild(link));
    mainNav.appendChild(moreMenu);
    const toggle = moreMenu.querySelector('.more-toggle');
    const closeMore = () => { moreMenu.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false'); };
    toggle.addEventListener('click', (event) => { event.stopPropagation(); const open = moreMenu.classList.toggle('open'); toggle.setAttribute('aria-expanded', String(open)); });
    dropdown.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMore));
    document.addEventListener('click', (event) => { if (!moreMenu.contains(event.target)) closeMore(); });
  }
}
menuToggle?.addEventListener('click', () => mainNav.classList.toggle('open'));

const previousYearQuestions = document.querySelector('#previousYearQuestions');
const previousYearFilter = document.querySelector('#previousYearFilter');
let previousYearSubjectFilter;
let previousYearSetFilter;
let previousYearBank = [];

function setupPreviousYearFilters() {
  if (!previousYearFilter) return;
  previousYearSubjectFilter = document.createElement('select');
  previousYearSubjectFilter.id = 'previousYearSubject';
  previousYearSubjectFilter.setAttribute('aria-label', 'Choose subject');
  previousYearSetFilter = document.createElement('select');
  previousYearSetFilter.id = 'previousYearSet';
  previousYearSetFilter.setAttribute('aria-label', 'Choose test set');
  const subjectLabel = document.createElement('label');
  subjectLabel.className = 'question-filter';
  subjectLabel.append('Subject', previousYearSubjectFilter);
  const setLabel = document.createElement('label');
  setLabel.className = 'question-filter';
  setLabel.append('Test set', previousYearSetFilter);
  previousYearFilter.closest('label')?.after(subjectLabel, setLabel);
}

function updatePreviousYearSubjects() {
  const exam = previousYearFilter?.value === 'all' ? 'SSC CGL' : (previousYearFilter?.value || 'SSC CGL');
  const subjects = exam === 'SSC CGL' ? ['English', 'Mathematics', 'Reasoning', 'General Awareness', 'Indian Polity'] : ['Mathematics', 'Reasoning', 'General Awareness', 'General Science', 'Indian Polity'];
  previousYearSubjectFilter.innerHTML = subjects.map((subject) => `<option value="${subject}">${subject}</option>`).join('');
  previousYearSetFilter.innerHTML = Array.from({ length: 50 }, (_, index) => `<option value="${index + 1}">Set ${index + 1}</option>`).join('');
}

function loadPreviousYearSet() {
  const exam = previousYearFilter?.value || 'SSC CGL';
  const subject = previousYearSubjectFilter?.value || 'English';
  const set = previousYearSetFilter?.value || '1';
  previousYearQuestions.innerHTML = '<p class="question-bank-status">Loading questions...</p>';
  const apiOrigin = window.location.port === '3000' ? 'http://127.0.0.1:3002' : '';
  fetch(`${apiOrigin}/api/question-sets?exam=${encodeURIComponent(exam)}&subject=${encodeURIComponent(subject)}&set=${set}`)
    .then((response) => response.json())
    .then((payload) => { previousYearBank = payload.questions || []; renderPreviousYearQuestions(); })
    .catch(() => { previousYearQuestions.innerHTML = '<p class="question-bank-status">Questions could not be loaded.</p>'; });
}

function renderPreviousYearQuestions() {
  if (!previousYearQuestions) return;
  const selectedExam = previousYearFilter?.value || 'all';
  const visibleQuestions = previousYearBank.filter((question) => selectedExam === 'all' || question.exam === selectedExam);
  previousYearQuestions.innerHTML = '';

  if (!visibleQuestions.length) {
    previousYearQuestions.innerHTML = '<p class="question-bank-status">No questions found for this exam.</p>';
    return;
  }

  visibleQuestions.forEach((question, index) => {
    const card = document.createElement('article');
    card.className = 'question-bank-card';
    const meta = document.createElement('span');
    meta.className = 'question-bank-meta';
    meta.textContent = `${question.exam} · ${question.year}`;
    const heading = document.createElement('h3');
    heading.textContent = `${index + 1}. ${question.topic}`;
    const prompt = document.createElement('p');
    prompt.textContent = question.text;
    const options = document.createElement('div');
    options.className = 'question-bank-options';
    question.options.forEach((option, optionIndex) => {
      const optionRow = document.createElement('span');
      optionRow.textContent = `${String.fromCharCode(65 + optionIndex)}. ${option}`;
      options.appendChild(optionRow);
    });
    const answer = document.createElement('button');
    answer.className = 'question-answer-button';
    answer.type = 'button';
    answer.textContent = 'Show answer';
    answer.addEventListener('click', () => {
      answer.textContent = `Answer: ${String.fromCharCode(65 + question.answer)}. ${question.options[question.answer]}`;
      answer.disabled = true;
    });
    const source = document.createElement('a');
    source.className = 'question-source-link';
    source.href = question.sourceUrl;
    source.target = '_blank';
    source.rel = 'noreferrer';
    source.textContent = 'View paper source';
    card.append(meta, heading, prompt, options, answer, source);
    previousYearQuestions.appendChild(card);
  });
}

if (previousYearQuestions) {
  setupPreviousYearFilters();
  updatePreviousYearSubjects();
  previousYearFilter?.addEventListener('change', () => { updatePreviousYearSubjects(); loadPreviousYearSet(); });
  previousYearSubjectFilter?.addEventListener('change', loadPreviousYearSet);
  previousYearSetFilter?.addEventListener('change', loadPreviousYearSet);
  loadPreviousYearSet();
}

const profileName = document.querySelector('#profileName');
const profileLabel = document.querySelector('#profileExamLabel');
const savedName = localStorage.getItem('preply-profile-name');
const savedExam = localStorage.getItem('preply-profile-exam') || 'SSC CGL';
const savedLocation = localStorage.getItem('preply-profile-location') || 'India';
const isAuthenticated = localStorage.getItem('preply-authenticated') === 'true';
const genderLabel = document.querySelector('#settingsLearnerType')?.parentElement;
if (genderLabel?.firstChild) genderLabel.firstChild.nodeValue = 'What is your gender?';
if (isAuthenticated && savedName && profileName) profileName.textContent = savedName;
if (profileLabel) profileLabel.textContent = isAuthenticated ? `${savedExam} aspirant · ${savedLocation}` : 'Sign in to view your personal profile';
if (!isAuthenticated && profileName) profileName.textContent = 'Your profile';

async function loadAccountProfile() {
  const email = localStorage.getItem('preply-account-email');
  if (!email || !profileName) return;

  try {
    const response = await fetch(`/api/profile/${encodeURIComponent(email)}`);
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Profile could not be loaded.');

    const user = payload.user;
    profileName.textContent = user.name;
    profileLabel.textContent = `${user.exam} aspirant · ${user.location}`;
    if (user.guestId) {
      let guestLabel = document.querySelector('#guestUserId');
      if (!guestLabel) {
        guestLabel = document.createElement('small');
        guestLabel.id = 'guestUserId';
        profileLabel.insertAdjacentElement('afterend', guestLabel);
      }
      guestLabel.textContent = `Guest ID: ${user.guestId}`;
    }
    const avatar = document.querySelector('.profile-avatar');
    if (avatar) avatar.textContent = user.name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
    localStorage.setItem('preply-profile-name', user.name);
    localStorage.setItem('preply-profile-exam', user.exam);
    localStorage.setItem('preply-profile-location', user.location);

    const goal = document.querySelector('#goalList .goal-item strong');
    if (goal) goal.textContent = `${user.exam} goal`;
    const messageMetric = document.querySelector('#profileMessagesSent');
    if (messageMetric) messageMetric.textContent = payload.stats?.messagesSent || 0;
    const metrics = document.querySelectorAll('.profile-metrics strong');
    if (metrics[0]) metrics[0].textContent = payload.stats?.testsTaken || 0;
    if (metrics[1]) metrics[1].textContent = `${payload.stats?.averageAccuracy || 0}%`;
    if (metrics[2]) metrics[2].textContent = formatStudyTime(payload.stats?.studyTimeMinutes || 0);
    const accuracyLabel = document.querySelectorAll('.profile-metrics span')[1];
    if (accuracyLabel) accuracyLabel.textContent = 'Average accuracy';
  } catch (error) {
    if (error.message === 'User not found.') {
      localStorage.removeItem('preply-authenticated');
      localStorage.removeItem('preply-account-email');
      localStorage.removeItem('preply-profile-name');
      localStorage.removeItem('preply-profile-exam');
      localStorage.removeItem('preply-profile-location');
      if (profileName) profileName.textContent = 'Your profile';
      if (profileLabel) profileLabel.textContent = 'Sign in to view your personal profile';
    }
    console.warn('Unable to load account profile:', error.message);
  }
}
loadAccountProfile();

function formatStudyTime(minutes) {
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return remainingMinutes ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
}

function updateLiveProfile(stats) {
  const metrics = document.querySelectorAll('.profile-metrics strong');
  if (metrics[0]) metrics[0].textContent = stats.testsTaken;
  if (metrics[1]) metrics[1].textContent = `${stats.averageAccuracy}%`;
  if (metrics[2]) metrics[2].textContent = formatStudyTime(stats.studyTimeMinutes);
  const accuracyLabel = document.querySelectorAll('.profile-metrics span')[1];
  if (accuracyLabel) accuracyLabel.textContent = 'Average accuracy';
}

if (profileName) {
  const profileStream = new EventSource('/api/chat/stream');
  profileStream.addEventListener('profile-updated', (event) => {
    const update = JSON.parse(event.data);
    if (update.email === localStorage.getItem('preply-account-email')) updateLiveProfile(update.stats);
  });
}

function savePageProfile() {
  const name = document.querySelector('#settingsName').value.trim();
  const exam = document.querySelector('#settingsExam').value.trim();
  const location = document.querySelector('#settingsLocation').value.trim();
  localStorage.setItem('preply-profile-name', name);
  localStorage.setItem('preply-profile-exam', exam);
  localStorage.setItem('preply-profile-location', location);
  if (profileName) profileName.textContent = name;
  if (profileLabel) profileLabel.textContent = `${exam} aspirant · ${location}`;
  document.querySelector('#settingsModal')?.classList.remove('visible');
}

document.querySelector('#profileSettings')?.addEventListener('click', () => {
  document.querySelector('#settingsName').value = profileName?.textContent || '';
  document.querySelector('#settingsExam').value = savedExam;
  document.querySelector('#settingsLocation').value = savedLocation;
  document.querySelector('#settingsModal').classList.add('visible');
});
document.querySelector('#settingsClose')?.addEventListener('click', () => document.querySelector('#settingsModal').classList.remove('visible'));
document.querySelector('#settingsForm')?.addEventListener('submit', (event) => { event.preventDefault(); savePageProfile(); });
document.querySelector('#addGoal')?.addEventListener('click', () => {
  const list = document.querySelector('#goalList');
  if (!list.querySelector('[data-added-goal]')) list.insertAdjacentHTML('beforeend', '<div class="goal-item" data-added-goal><span class="goal-icon blue-icon">C</span><div><strong>CTET Paper I</strong><span>Exam in 118 days</span></div><b>8%</b></div>');
});

document.querySelector('#newQuote')?.addEventListener('click', () => {
  const quotes = ['“The score follows the habit. Protect your habit today.”', '“One solved question is one less question between you and your goal.”', '“Your future result is built in ordinary minutes like this one.”'];
  const quote = document.querySelector('#motivationQuote');
  quote.textContent = quotes[Math.floor(Math.random() * quotes.length)];
});
document.querySelector('#researchRefresh')?.addEventListener('click', () => {
  const updates = ['Focus on data interpretation in your next timed set.', 'Revise percentage and ratio shortcuts before your next mock.', 'Add a 15-question reasoning sprint to today\'s plan.'];
  document.querySelector('#researchText').textContent = `${savedExam}: ${updates[Math.floor(Math.random() * updates.length)]}`;
});

document.querySelector('#resourceNotify')?.addEventListener('click', () => {
  localStorage.setItem('preply-resource-notifications', 'on');
  document.querySelector('#resourceNotice').hidden = false;
});

const chatForm = document.querySelector('#chatForm');
const chatInput = document.querySelector('#chatInput');
const chatMessages = document.querySelector('#chatMessages');
const chatLockNotice = document.querySelector('#chatLockNotice');
const lockKey = 'preply-chat-locked-until';
const abusiveWords = ['abuseword', 'idiot', 'stupid', 'shut up', ' hate ', 'kill yourself'];
function applyChatPageLock() {
  const until = Number(localStorage.getItem(lockKey) || 0);
  const locked = until > Date.now();
  if (chatInput) chatInput.disabled = locked;
  if (chatForm) chatForm.querySelector('button').disabled = locked;
  if (chatLockNotice) {
    chatLockNotice.hidden = !locked;
    if (locked) chatLockNotice.textContent = `Chat access is paused for ${Math.ceil((until - Date.now()) / 86400000)} days because abusive language was detected.`;
  }
}
applyChatPageLock();
function appendChatMessage(message) {
  const row = document.createElement('div');
  const isStudent = message.author === 'student';
  row.className = `chat-message ${isStudent ? 'student' : 'topper'}`;
  row.innerHTML = isStudent
    ? '<div><b>You</b><p></p></div><span class="chat-avatar you-avatar">AS</span>'
    : '<span class="chat-avatar">MT</span><div><b>Mentor</b><p></p></div>';
  row.querySelector('p').textContent = message.text;
  chatMessages.appendChild(row);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

if (chatMessages) {
  const chatStream = new EventSource('/api/chat/stream');
  chatStream.addEventListener('message', (event) => appendChatMessage(JSON.parse(event.data)));
}

chatForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!message || Number(localStorage.getItem(lockKey) || 0) > Date.now()) return;

  if (abusiveWords.some((word) => ` ${message.toLowerCase()} `.includes(word))) {
    localStorage.setItem(lockKey, String(Date.now() + 7 * 86400000));
    applyChatPageLock();
    return;
  }

  try {
    const response = await fetch('/api/chat/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: message,
        author: 'student',
        email: localStorage.getItem('preply-account-email') || ''
      })
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Message could not be sent.');

    chatInput.value = '';
  } catch (error) {
    chatLockNotice.hidden = false;
    chatLockNotice.textContent = error.message;
  }
});