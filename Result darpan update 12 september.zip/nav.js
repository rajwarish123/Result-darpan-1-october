(() => {
  const nav = document.querySelector('.main-nav');
  if (!nav || nav.querySelector('.more-menu')) return;
  nav.querySelectorAll(':scope > a').forEach((link) => {
    if (link.textContent.trim().toLowerCase() === 'admin dashboard') link.remove();
  });

  const keepLabels = new Set(['my profile', 'contact us', 'about us', 'test series', 'chat with mentor']);
  const existingLabels = new Set([...nav.querySelectorAll(':scope > a')].map((link) => link.textContent.replace('↗', '').trim().toLowerCase()));
  [['Contact us', 'contact.html'], ['About us', 'index.html#stats']].forEach(([label, href]) => {
    if (!existingLabels.has(label.toLowerCase())) {
      const link = document.createElement('a');
      link.href = href;
      link.textContent = label;
      nav.appendChild(link);
    }
  });
  const links = [...nav.querySelectorAll(':scope > a')];
  const movedLinks = links.filter((link) => !keepLabels.has(link.textContent.replace('↗', '').trim().toLowerCase()));
  if (!movedLinks.length) return;

  const moreMenu = document.createElement('div');
  moreMenu.className = 'more-menu';
  moreMenu.innerHTML = '<button class="more-toggle" type="button" aria-expanded="false">More <span>⌄</span></button><div class="more-dropdown"></div>';
  const dropdown = moreMenu.querySelector('.more-dropdown');
  movedLinks.forEach((link) => dropdown.appendChild(link));
  nav.appendChild(moreMenu);

  const toggle = moreMenu.querySelector('.more-toggle');
  const closeMenu = () => {
    moreMenu.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
  };
  toggle.addEventListener('click', (event) => {
    event.stopPropagation();
    const open = moreMenu.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
  dropdown.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('click', (event) => {
    if (!moreMenu.contains(event.target)) closeMenu();
  });
})();
