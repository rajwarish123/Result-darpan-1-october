const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');
const examsSection = document.querySelector('#exams');
if (examsSection && !document.querySelector('#schoolClasses')) {
  const schoolClasses = document.createElement('section');
  schoolClasses.id = 'schoolClasses';
  schoolClasses.className = 'school-classes-section';
  schoolClasses.innerHTML = '<div class="shell"><div class="section-heading"><div><span class="kicker">SCHOOL PREP</span><h2>Build strong basics<br><em>from Class 9 to 12.</em></h2></div><span class="subject-note">Choose your class for focused school-level practice and revision.</span></div><div class="school-class-grid"><button class="school-class-card" data-school-class="9"><span>09</span><strong>Class 9</strong><small>Foundation practice</small></button><button class="school-class-card" data-school-class="10"><span>10</span><strong>Class 10</strong><small>Boards and basics</small></button><button class="school-class-card" data-school-class="11"><span>11</span><strong>Class 11</strong><small>Concept building</small></button><button class="school-class-card" data-school-class="12"><span>12</span><strong>Class 12</strong><small>Boards and entrance prep</small></button></div></div>';
  examsSection.before(schoolClasses);
  schoolClasses.querySelectorAll('.school-class-card').forEach((card) => {
    card.addEventListener('click', () => {
      window.localStorage.setItem('preply-school-class', card.dataset.schoolClass);
      schoolClasses.querySelector('.school-class-card.selected')?.classList.remove('selected');
      card.classList.add('selected');
      document.querySelector('#subjects')?.scrollIntoView({ behavior: 'smooth' });
    });
  });
  const savedSchoolClass = window.localStorage.getItem('preply-school-class');
  schoolClasses.querySelector(`[data-school-class="${savedSchoolClass}"]`)?.classList.add('selected');
}
const subjectsSection = document.querySelector('#subjects');
const signupBand = document.querySelector('#resources');
const testimonialsSection = document.querySelector('#testimonials');
const chatSection = document.querySelector('#chat');
const profileSection = document.querySelector('#profile');
if (subjectsSection && signupBand) subjectsSection.after(signupBand);
if (signupBand && testimonialsSection) signupBand.after(testimonialsSection);
if (subjectsSection && chatSection) subjectsSection.after(chatSection);
if (chatSection && profileSection) chatSection.after(profileSection);
if (subjectsSection && !document.querySelector('#previousYearBand')) {
  const previousYearBand = document.createElement('section');
  previousYearBand.id = 'previousYearBand';
  previousYearBand.className = 'previous-year-band';
  previousYearBand.innerHTML = '<div class="shell previous-year-band-inner"><div><span class="kicker">EXAM PATTERN PRACTICE</span><h2>Previous year questions,<br><em>one focused set at a time.</em></h2><p>Practise SSC CGL, Railway NTPC, and Railway Group D question patterns in one dedicated library.</p></div><a class="primary-btn" href="previous-year-questions.html">Explore previous year questions <span>→</span></a></div>';
  subjectsSection.before(previousYearBand);
}
if (nav && !nav.querySelector('a[href="previous-year-questions.html"]')) {
  const previousYearLink = document.createElement('a');
  previousYearLink.href = 'previous-year-questions.html';
  previousYearLink.textContent = 'Previous year questions';
  nav.appendChild(previousYearLink);
}
document.querySelectorAll('a').forEach((link) => {
  if (link.textContent.trim().toLowerCase() === 'contact') link.href = 'contact.html';
  if (link.textContent.trim().toLowerCase() === 'privacy') link.href = 'privacy.html';
});
document.querySelector('#editProfile')?.remove();
document.querySelector('.learner-choice')?.remove();
document.querySelector('#updateModal')?.remove();
document.querySelector('.subject-tabs')?.remove();
const statsSection = document.querySelector('.stats-section');
const heroSection = document.querySelector('.hero');
if (statsSection && heroSection) heroSection.parentNode.insertBefore(statsSection, heroSection);

menuToggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? '×' : '☰';
});

document.querySelectorAll('.main-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    if (menuToggle) menuToggle.textContent = '☰';
  });
});

document.querySelectorAll('.category').forEach((category) => {
  category.addEventListener('click', () => {
    document.querySelector('.category.active')?.classList.remove('active');
    category.classList.add('active');
    const filter = category.dataset.filter;
    document.querySelectorAll('.test-card').forEach((card) => {
      card.hidden = filter !== 'all' && card.dataset.category !== filter;
    });
  });
});

document.querySelectorAll('.subject-test-btn').forEach((button) => {
  button.addEventListener('click', () => {
    const requestedSubject = button.closest('.subject-card')?.dataset.subject;
    activeQuestionSubject = requestedSubject;
    openTest();
  });
});

document.querySelector('.email-box button')?.addEventListener('click', () => {
  const input = document.querySelector('.email-box input');
  if (input.value.trim()) {
    input.value = '';
    input.placeholder = 'You are on the list ✓';
  } else {
    input.focus();
  }
});

document.querySelector('.login-btn')?.addEventListener('click', () => openAuth('login'));
document.querySelectorAll('.nav-cta, .signup-band .primary-btn').forEach((button) => {
  button.addEventListener('click', () => {
    if (button.classList.contains('nav-cta') && window.localStorage.getItem('preply-authenticated') === 'true') {
      window.localStorage.removeItem('preply-authenticated');
      window.localStorage.removeItem('preply-account-email');
      window.localStorage.removeItem('preply-guest-id');
      window.localStorage.removeItem('preply-is-guest');
      syncAuthButton();
      return;
    }
    openAuth('signup');
  });
});

let questions = [
  { topic: 'English Comprehension', text: 'Choose the correctly spelt word.', options: ['Accomodation', 'Accommodation', 'Acommodation', 'Accommadation'], answer: 1 },
  { topic: 'Quantitative Aptitude', text: 'What is 15% of 240?', options: ['24', '30', '36', '42'], answer: 2 },
  { topic: 'General Intelligence', text: 'Find the next number in the series: 3, 8, 15, 24, 35, ?', options: ['42', '46', '48', '50'], answer: 2 },
  { topic: 'General Awareness', text: 'Which fundamental right is known as the Right to Constitutional Remedies?', options: ['Article 14', 'Article 19', 'Article 21', 'Article 32'], answer: 3 },
  { topic: 'Quantitative Aptitude', text: 'A train covers 360 km in 4 hours. What is its average speed?', options: ['80 km/h', '90 km/h', '100 km/h', '120 km/h'], answer: 1 },
  { topic: 'English Comprehension', text: 'Choose the antonym of “Transparent”.', options: ['Clear', 'Visible', 'Opaque', 'Bright'], answer: 2 },
  { topic: 'General Intelligence', text: 'If CAT is coded as DBU, how is DOG coded?', options: ['EPH', 'EOG', 'DPH', 'FPI'], answer: 0 },
  { topic: 'General Awareness', text: 'The headquarters of the United Nations is located in:', options: ['Geneva', 'New York', 'Paris', 'London'], answer: 1 },
  { topic: 'Quantitative Aptitude', text: 'What is the simple interest on ₹5,000 at 8% per annum for 2 years?', options: ['₹400', '₹600', '₹800', '₹1,000'], answer: 2 },
  { topic: 'General Awareness', text: 'Which gas is most abundant in Earth’s atmosphere?', options: ['Oxygen', 'Carbon dioxide', 'Hydrogen', 'Nitrogen'], answer: 3 }
];

const apiOrigin = window.location.port === '3000' ? 'http://127.0.0.1:3002' : '';
const questionBankPromise = fetch(`${apiOrigin}/api/questions`)
  .then((response) => response.ok ? response.json() : { questions: [] })
  .then((payload) => { questions = questions.concat(payload.questions || []); })
  .catch(() => {});

const testModal = document.querySelector('#testModal');
const questionText = document.querySelector('#questionText');
const questionTopic = document.querySelector('#questionTopic');
const answerOptions = document.querySelector('#answerOptions');
const questionMap = document.querySelector('#questionMap');
const questionCount = document.querySelector('#questionCount');
const progressBar = document.querySelector('#progressBar');
const testTimer = document.querySelector('#testTimer');
const testResult = document.querySelector('#testResult');
const leaderboardRows = document.querySelector('#leaderboardRows');
let currentQuestion = 0;
let answers = Array(questions.length).fill(null);
let timerId;
let secondsLeft = 900;
let testStartedAt = 0;
let activeQuestionSubject = null;

function formatStudyTime(minutes) {
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return remainingMinutes ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
}

function updateProfileMetrics(stats) {
  const testsMetric = document.querySelector('#profileTests');
  const bestMetric = document.querySelector('#profileBest');
  const studyMetric = document.querySelector('#profileStudyTime');
  if (testsMetric) testsMetric.textContent = stats.testsTaken;
  if (bestMetric) bestMetric.textContent = `${stats.averageAccuracy}%`;
  if (studyMetric) studyMetric.textContent = formatStudyTime(stats.studyTimeMinutes);
  const accuracyLabel = document.querySelectorAll('.profile-metrics span')[1];
  if (accuracyLabel) accuracyLabel.textContent = 'Average accuracy';
}

function getCurrentExam() {
  const exam = window.localStorage.getItem('preply-profile-exam') || 'SSC CGL';
  if (/group\s*d/i.test(exam)) return 'Railway Group D';
  if (/ntpc|railway/i.test(exam)) return 'Railway NTPC';
  return 'SSC CGL';
}

function getQuestionSetSubject(subject, exam) {
  if (subject === 'mathematics') return 'Mathematics';
  if (subject === 'reasoning') return 'Reasoning';
  if (subject === 'polity') return 'Indian Polity';
  if (subject === 'science' && exam !== 'SSC CGL') return 'General Science';
  if (subject === 'english' && exam === 'SSC CGL') return 'English';
  return 'General Awareness';
}

async function loadSubjectQuestionSet() {
  if (!activeQuestionSubject) return;
  const exam = getCurrentExam();
  const subject = getQuestionSetSubject(activeQuestionSubject, exam);
  const response = await fetch(`${apiOrigin}/api/question-sets?exam=${encodeURIComponent(exam)}&subject=${encodeURIComponent(subject)}&set=1`);
  const payload = await response.json();
  if (!response.ok || !Array.isArray(payload.questions)) throw new Error('Subject questions could not be loaded.');
  questions = payload.questions;
}

function renderQuestion() {
  const question = questions[currentQuestion];
  questionTopic.textContent = [question.exam, question.year, question.topic].filter(Boolean).join(' · ');
  questionText.textContent = question.text;
  questionCount.textContent = `Question ${currentQuestion + 1} of ${questions.length}`;
  progressBar.style.width = `${((currentQuestion + 1) / questions.length) * 100}%`;
  answerOptions.innerHTML = question.options.map((option, index) => `<button class="answer-option${answers[currentQuestion] === index ? ' selected' : ''}" data-answer="${index}"><span>${String.fromCharCode(65 + index)}</span>${option}</button>`).join('');
  questionMap.innerHTML = questions.map((_, index) => `<button class="map-item${index === currentQuestion ? ' current' : ''}${answers[index] !== null ? ' answered' : ''}" data-question="${index}">${index + 1}</button>`).join('');
  document.querySelector('#previousQuestion').disabled = currentQuestion === 0;
  document.querySelector('#nextQuestion').innerHTML = currentQuestion === questions.length - 1 ? 'Submit test <span>✓</span>' : 'Next question <span>→</span>';
}

function updateTimer() {
  const minutes = Math.floor(secondsLeft / 60).toString().padStart(2, '0');
  const seconds = (secondsLeft % 60).toString().padStart(2, '0');
  testTimer.textContent = `${minutes}:${seconds}`;
  if (secondsLeft <= 60) testTimer.classList.add('urgent');
  if (secondsLeft <= 0) finishTest();
  secondsLeft -= 1;
}

async function openTest() {
  await questionBankPromise;
  try {
    await loadSubjectQuestionSet();
  } catch (error) {
    console.warn(error.message);
  }
  currentQuestion = 0;
  answers = Array(questions.length).fill(null);
  secondsLeft = 900;
  testStartedAt = Date.now();
  testTimer.classList.remove('urgent');
  testResult.hidden = true;
  document.querySelector('.test-body').hidden = false;
  document.querySelector('.test-progress').hidden = false;
  testModal.classList.add('visible');
  testModal.setAttribute('aria-hidden', 'false');
  renderQuestion();
  updateTimer();
  clearInterval(timerId);
  timerId = setInterval(updateTimer, 1000);
}

function closeTest() {
  clearInterval(timerId);
  testModal.classList.remove('visible');
  testModal.setAttribute('aria-hidden', 'true');
}

async function saveTestResult(correct, total) {
  const email = window.localStorage.getItem('preply-account-email');
  if (!email || window.localStorage.getItem('preply-authenticated') !== 'true') return;

  try {
    const response = await fetch(`/api/profile/${encodeURIComponent(email)}/test-results`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ score: correct, total, durationSeconds: Math.max(1, Math.round((Date.now() - testStartedAt) / 1000)) })
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Test result could not be saved.');

    updateProfileMetrics(payload.stats);
  } catch (error) {
    console.warn('Unable to save test result:', error.message);
  }
}

function finishTest() {
  clearInterval(timerId);
  const correct = answers.reduce((total, answer, index) => total + (answer === questions[index].answer ? 1 : 0), 0);
  const attempted = answers.filter((answer) => answer !== null).length;
  saveTestResult(correct, questions.length);
  document.querySelector('.test-body').hidden = true;
  document.querySelector('.test-progress').hidden = true;
  testResult.hidden = false;
  document.querySelector('#resultScore').textContent = `${correct}/${questions.length}`;
  document.querySelector('#resultPercent').textContent = `${Math.round((correct / questions.length) * 100)}%`;
  document.querySelector('#resultCorrect').textContent = `${correct}`;
  document.querySelector('#resultSummary').textContent = `You attempted ${attempted} of ${questions.length} questions. Review the solutions and keep your momentum going.`;
  document.querySelector('#resultTitle').textContent = correct >= 7 ? 'Strong start.' : 'Good first attempt.';
  const encouragements = [
    'Review the questions you missed, then take one focused set today.',
    'A difficult attempt is useful data. Come back with one topic better prepared.',
    'Do not stop at this score. Small daily improvements compound quickly.',
    'Your next attempt starts with the question you choose to practise now.'
  ];
  const encouragement = document.querySelector('#resultEncouragement');
  if (correct < 7) {
    encouragement.hidden = false;
    document.querySelector('#resultEncouragementText').textContent = encouragements[Math.floor(Math.random() * encouragements.length)];
  } else {
    encouragement.hidden = true;
  }
  const totalParticipants = 6110;
  const percentile = Math.max(4, Math.min(98, 28 + (correct * 7)));
  const peopleAbove = Math.max(0, Math.round(totalParticipants * (1 - percentile / 100)));
  document.querySelector('#resultAbove').textContent = `${percentile}%`;
  document.querySelector('#resultSubmitted').textContent = totalParticipants.toLocaleString('en-IN');
  document.querySelector('#resultRank').textContent = `#${(peopleAbove + 1).toLocaleString('en-IN')}`;
  const leaderboard = [
    ['Aarav Mehta', '10/10', '99%', 'AM'],
    ['Ishita Rao', '9/10', '94%', 'IR'],
    ['You', `${correct}/${questions.length}`, `${percentile}%`, 'YO'],
    ['Rohan Singh', '7/10', '78%', 'RS']
  ];
  leaderboardRows.innerHTML = leaderboard.map(([name, score, accuracy, initials]) => `<div class="leaderboard-row${name === 'You' ? ' you' : ''}"><span class="leader-avatar">${initials}</span><strong>${name}</strong><span>${score}</span><span>${accuracy}</span></div>`).join('');
  launchConfetti();
}

function launchConfetti() {
  const colors = ['#f27e63', '#f7cc55', '#175e4b', '#7dbb91', '#e7b07d'];
  const confetti = document.createElement('div');
  confetti.className = 'confetti';
  confetti.innerHTML = Array.from({ length: 46 }, (_, index) => `<i style="--x:${Math.random() * 100}vw;--delay:${Math.random() * .18}s;--duration:${1.4 + Math.random() * 1.2}s;--color:${colors[index % colors.length]};--rotate:${Math.random() * 360}deg"></i>`).join('');
  document.body.appendChild(confetti);
  window.setTimeout(() => confetti.remove(), 3000);
}

document.querySelectorAll('.start-test').forEach((button) => button.addEventListener('click', () => { activeQuestionSubject = null; openTest(); }));
document.querySelector('.close-test')?.addEventListener('click', closeTest);
testModal?.addEventListener('click', (event) => { if (event.target === testModal) closeTest(); });
document.querySelector('#answerOptions')?.addEventListener('click', (event) => {
  const option = event.target.closest('.answer-option');
  if (!option) return;
  answers[currentQuestion] = Number(option.dataset.answer);
  renderQuestion();
});
document.querySelector('#previousQuestion')?.addEventListener('click', () => { if (currentQuestion > 0) { currentQuestion -= 1; renderQuestion(); } });
document.querySelector('#nextQuestion')?.addEventListener('click', () => { if (currentQuestion === questions.length - 1) finishTest(); else { currentQuestion += 1; renderQuestion(); } });
document.querySelector('#questionMap')?.addEventListener('click', (event) => { const item = event.target.closest('.map-item'); if (item) { currentQuestion = Number(item.dataset.question); renderQuestion(); } });
document.querySelector('#retryTest')?.addEventListener('click', openTest);
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && testModal?.classList.contains('visible')) closeTest(); });

const authModal = document.querySelector('#authModal');
const authForm = document.querySelector('#authForm');
const authTitle = document.querySelector('#authTitle');
const authSubmit = document.querySelector('.auth-submit');
const authClose = document.querySelector('#authClose');
const authTabs = document.querySelectorAll('.auth-tab');
authForm?.setAttribute('autocomplete', 'on');
authForm?.querySelector('input[type="email"]')?.setAttribute('autocomplete', 'username');
authForm?.querySelector('input[type="email"]')?.setAttribute('name', 'email');
authForm?.querySelector('input[type="password"]')?.setAttribute('name', 'password');
document.querySelector('#signupName')?.setAttribute('autocomplete', 'name');
document.querySelector('#signupName')?.setAttribute('name', 'name');
document.querySelector('#signupLocation')?.setAttribute('autocomplete', 'address-level2');
document.querySelector('#signupLocation')?.setAttribute('name', 'location');

function createLearnerTypeField(container, id) {
  if (!container || container.querySelector(`#${id}`)) return;
    const label = document.createElement('label');
    label.textContent = 'What is your gender?';
  const select = document.createElement('select');
  select.id = id;
  select.innerHTML = '<option value="boy">Boy</option><option value="girl">Girl</option><option value="other">Other · flower</option>';
  label.appendChild(select);
  container.appendChild(label);
}
createLearnerTypeField(document.querySelector('#signupFields'), 'signupLearnerType');
createLearnerTypeField(document.querySelector('#settingsForm'), 'settingsLearnerType');
const authError = document.createElement('p');
authError.className = 'auth-error';
authError.setAttribute('role', 'alert');
authError.hidden = true;
authForm?.insertBefore(authError, authForm.querySelector('.auth-submit'));
const forgotPassword = document.createElement('button');
forgotPassword.type = 'button';
forgotPassword.className = 'forgot-password';
forgotPassword.textContent = 'Forgot password?';
authForm?.appendChild(forgotPassword);
const recoveryPanel = document.createElement('div');
recoveryPanel.className = 'recovery-panel';
recoveryPanel.hidden = true;
recoveryPanel.innerHTML = '<button type="button" class="back-to-login">← Back to login</button><h3>Reset your password</h3><p class="recovery-copy">Enter your account email and we will send a one-time password.</p><label>Email address<input class="recovery-email" type="email" autocomplete="username" placeholder="you@example.com"></label><button type="button" class="primary-btn send-otp">Send OTP <span>→</span></button><div class="otp-step" hidden><label>Enter OTP<input class="otp-input" inputmode="numeric" maxlength="6" placeholder="6-digit OTP"></label><button type="button" class="primary-btn verify-otp">Verify OTP <span>✓</span></button></div><div class="new-password-step" hidden><label>New password<input class="new-password" type="password" minlength="8" autocomplete="new-password" placeholder="At least 8 characters"></label><button type="button" class="primary-btn reset-password">Update password <span>→</span></button></div><p class="recovery-message" role="alert"></p>';
authForm?.parentElement.appendChild(recoveryPanel);
const recoveryMessage = recoveryPanel.querySelector('.recovery-message');
function showRecoveryMessage(message, error = false) { recoveryMessage.textContent = message; recoveryMessage.classList.toggle('error', error); }
forgotPassword.addEventListener('click', () => { authForm.hidden = true; recoveryPanel.hidden = false; });
recoveryPanel.querySelector('.back-to-login').addEventListener('click', () => { recoveryPanel.hidden = true; authForm.hidden = false; showRecoveryMessage(''); });
recoveryPanel.querySelector('.send-otp').addEventListener('click', () => {
  const email = recoveryPanel.querySelector('.recovery-email').value.trim().toLowerCase();
  const savedEmail = window.localStorage.getItem('preply-account-email');

  if (!savedEmail || email !== savedEmail) {
    showRecoveryMessage('We could not find an account with that email.', true);
    return;
  }

  const otp = '123456';
  window.sessionStorage.setItem('preply-reset-otp', otp);
  recoveryPanel.querySelector('.otp-step').hidden = false;
  showRecoveryMessage(`OTP sent to ${email}. Demo OTP: ${otp}`);
});
recoveryPanel.querySelector('.verify-otp').addEventListener('click', () => {
  const entered = recoveryPanel.querySelector('.otp-input').value.trim();
  if (entered !== window.sessionStorage.getItem('preply-reset-otp')) { showRecoveryMessage('That OTP is incorrect. Please try again.', true); return; }
  recoveryPanel.querySelector('.new-password-step').hidden = false;
  recoveryPanel.querySelector('.otp-step').hidden = true;
  showRecoveryMessage('OTP verified. Choose a new password.');
});
recoveryPanel.querySelector('.reset-password').addEventListener('click', async () => {
  const email = recoveryPanel.querySelector('.recovery-email').value.trim().toLowerCase();
  const password = recoveryPanel.querySelector('.new-password').value;
  const otp = recoveryPanel.querySelector('.otp-input').value.trim();

  if (password.length < 8) { showRecoveryMessage('Your new password must be at least 8 characters.', true); return; }

  try {
    const response = await apiRequest('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, otp, newPassword: password })
    });

    window.localStorage.setItem('preply-account-password', password);
    window.sessionStorage.removeItem('preply-reset-otp');
    recoveryPanel.hidden = true;
    authForm.hidden = false;
    setAuthMode('login');
    showRecoveryMessage('');
    authError.textContent = response.message || 'Password updated. You can now log in.';
    authError.hidden = false;
  } catch (error) {
    showRecoveryMessage(error.message, true);
  }
});

function closeAuth() {
  authModal.classList.remove('visible');
  authModal.setAttribute('aria-hidden', 'true');
  window.localStorage.setItem('preply-welcomed', 'true');
}

function openAuth(mode = 'login') {
  setAuthMode(mode);
  authModal.classList.add('visible');
  authModal.setAttribute('aria-hidden', 'false');
}

function setAuthMode(mode) {
  const isGuest = mode === 'guest';
  const isSignup = mode === 'signup' || isGuest;
  authTabs.forEach((tab) => {
    const active = tab.dataset.authTab === mode;
    tab.classList.toggle('active', active);
    tab.setAttribute('aria-selected', String(active));
  });
  authTitle.innerHTML = isGuest ? 'Create your<br>guest profile.' : (isSignup ? 'Build your<br>winning streak.' : 'Your best attempt<br>starts here.');
  authSubmit.innerHTML = isGuest ? 'Create guest profile <span>→</span>' : (isSignup ? 'Create free account <span>→</span>' : 'Log in to Result Darpan <span>→</span>');
  const emailInput = authForm.querySelector('input[type="email"]');
  const passwordInput = authForm.querySelector('input[type="password"]');
  emailInput.parentElement.hidden = isGuest;
  passwordInput.parentElement.hidden = isGuest;
  emailInput.required = !isGuest;
  passwordInput.required = !isGuest;
  passwordInput.placeholder = isSignup && !isGuest ? 'Create a password' : 'At least 8 characters';
  passwordInput.setAttribute('autocomplete', isSignup && !isGuest ? 'new-password' : 'current-password');
  document.querySelector('#signupFields').hidden = !isSignup;
  document.querySelectorAll('#signupFields input').forEach((input) => { input.required = isSignup; });
  authError.hidden = true;
  forgotPassword.hidden = isSignup;
  recoveryPanel.hidden = true;
  authForm.hidden = false;
}

authTabs.forEach((tab) => tab.addEventListener('click', () => setAuthMode(tab.dataset.authTab)));
setAuthMode('login');
document.querySelector('#continueGuest')?.addEventListener('click', () => openAuth('guest'));
authClose?.addEventListener('click', closeAuth);
authModal?.addEventListener('click', (event) => { if (event.target === authModal) closeAuth(); });
authForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const isGuest = authSubmit.textContent.toLowerCase().includes('guest');
  const isSignup = !document.querySelector('#signupFields').hidden && !isGuest;
  const email = authForm.querySelector('input[type="email"]').value.trim().toLowerCase();
  const password = authForm.querySelector('input[type="password"]').value;

  try {
    if (isGuest) {
      const name = document.querySelector('#signupName').value.trim();
      const exam = document.querySelector('#signupExam').value.trim();
      const location = document.querySelector('#signupLocation').value.trim();
      const type = document.querySelector('#signupLearnerType')?.value || 'boy';
      const response = await apiRequest('/api/auth/guest', {
        method: 'POST',
        body: JSON.stringify({ name, exam, location })
      });

      saveProfileDetails(name, exam, location, type);
      window.localStorage.setItem('preply-account-email', response.user.email);
      window.localStorage.setItem('preply-guest-id', response.guestId);
      window.localStorage.setItem('preply-is-guest', 'true');
      window.localStorage.setItem('preply-authenticated', 'true');
      window.localStorage.setItem('preply-welcomed', 'true');
      showGuestId(response.guestId);
      syncAuthButton();
      closeAuth();
      return;
    }

    if (isSignup) {
      const name = document.querySelector('#signupName').value.trim();
      const exam = document.querySelector('#signupExam').value.trim();
      const location = document.querySelector('#signupLocation').value.trim();
      const type = document.querySelector('#signupLearnerType')?.value || 'boy';

      const response = await apiRequest('/api/auth/signup', {
        method: 'POST',
        body: JSON.stringify({ name, email, password, exam, location })
      });

      saveProfileDetails(name, exam || 'SSC CGL', location || 'India', type);
      window.localStorage.setItem('preply-account-email', email);
      window.localStorage.removeItem('preply-guest-id');
      window.localStorage.removeItem('preply-is-guest');
      window.localStorage.setItem('preply-account-password', password);
      window.localStorage.setItem('preply-authenticated', 'true');
      authError.hidden = true;
      syncAuthButton();
      closeAuth();
      return;
    }

    const savedEmail = window.localStorage.getItem('preply-account-email');
    const savedPassword = window.localStorage.getItem('preply-account-password');
    const response = await apiRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });

    if (!savedEmail || email !== savedEmail || password !== savedPassword) {
      window.localStorage.setItem('preply-account-email', email);
      window.localStorage.setItem('preply-account-password', password);
    }

    if (response.user && response.user.name) {
      saveProfileDetails(response.user.name, response.user.exam || 'SSC CGL', response.user.location || 'India', window.localStorage.getItem('preply-learner-type') || 'boy');
    }

    window.localStorage.setItem('preply-authenticated', 'true');
    window.localStorage.removeItem('preply-guest-id');
    window.localStorage.removeItem('preply-is-guest');
    syncAuthButton();
    closeAuth();
  } catch (error) {
    authError.textContent = error.message;
    authError.hidden = false;
  }
});

async function apiRequest(endpoint, options = {}) {
  const response = await fetch(endpoint, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    headers: {
      ...(options.headers || {}),
      'Content-Type': 'application/json'
    }
  });

  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('application/json') ? await response.json() : {};

  if (!response.ok) {
    throw new Error(payload.error || 'Request failed.');
  }

  return payload;
}

function syncAuthButton() {
  const accountButton = document.querySelector('.nav-cta');
  if (!accountButton) return;
  const authenticated = window.localStorage.getItem('preply-authenticated') === 'true';
  accountButton.classList.toggle('logout-button', authenticated);
  accountButton.innerHTML = authenticated ? 'Log out <span>↗</span>' : 'Create free account <span>→</span>';
  accountButton.setAttribute('aria-label', authenticated ? 'Log out' : 'Create free account');
}
syncAuthButton();
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && authModal?.classList.contains('visible')) closeAuth(); });

if (!window.localStorage.getItem('preply-welcomed')) {
  window.setTimeout(() => {
    authModal?.classList.add('visible');
    authModal?.setAttribute('aria-hidden', 'false');
  }, 450);
}

const motivationQuotes = [
  '“Consistency is a quiet superpower. Show up for one more question.”',
  '“You do not need a perfect day. You need one honest practice session.”',
  '“The score follows the habit. Protect your habit today.”',
  '“One solved question is one less question standing between you and your goal.”',
  '“Your future result is built in ordinary minutes like this one.”'
];
const researchUpdates = [
  ['SSC CGL', 'Tier-I mock tests are focusing more on data interpretation. Add one DI set to your next practice session.'],
  ['SSC CGL', 'Your reasoning accuracy improves fastest with timed series questions. Try 15 questions before your next mock.'],
  ['CURRENT AFFAIRS', 'Make a five-minute daily revision habit. Short, repeated reviews beat one long session at the weekend.'],
  ['QUANT', 'Percentage and ratio questions appear across several SSC CGL topics. Keep a formula card beside your practice set.']
];

document.querySelector('#newQuote')?.addEventListener('click', () => {
  const quote = document.querySelector('#motivationQuote');
  const current = quote.textContent;
  let next = current;
  while (next === current) next = motivationQuotes[Math.floor(Math.random() * motivationQuotes.length)];
  quote.classList.remove('quote-pop');
  void quote.offsetWidth;
  quote.textContent = next;
  quote.classList.add('quote-pop');
});

document.querySelector('#researchRefresh')?.addEventListener('click', (event) => {
  const update = researchUpdates[Math.floor(Math.random() * researchUpdates.length)];
  document.querySelector('#researchTag').textContent = update[0];
  document.querySelector('#researchText').textContent = update[1];
  document.querySelector('#researchTime').textContent = 'Updated just now · Result Darpan research desk';
  event.currentTarget.classList.add('spin-once');
  window.setTimeout(() => event.currentTarget.classList.remove('spin-once'), 400);
});

document.querySelector('#addGoal')?.addEventListener('click', () => {
  const goalList = document.querySelector('#goalList');
  if (goalList.querySelector('[data-added-goal]')) return;
  goalList.insertAdjacentHTML('beforeend', '<div class="goal-item" data-added-goal><span class="goal-icon blue-icon">C</span><div><strong>CTET Paper I</strong><span>Exam in 118 days</span></div><b>8%</b></div>');
});

function saveProfileDetails(name, exam, location, type = window.localStorage.getItem('preply-learner-type') || 'boy') {
  window.localStorage.setItem('preply-profile-name', name.trim());
  window.localStorage.setItem('preply-profile-exam', exam.trim());
  window.localStorage.setItem('preply-profile-location', location.trim());
  setLearnerType(type);
  document.querySelector('#profileName').textContent = name.trim();
  const profileLabel = document.querySelector('#profileExamLabel') || document.querySelector('#profileName')?.nextElementSibling;
  if (profileLabel) { profileLabel.id = 'profileExamLabel'; profileLabel.textContent = `${exam.trim()} aspirant · ${location.trim()}`; }
  document.querySelector('#researchTag').textContent = exam.trim().toUpperCase();
  document.querySelector('#researchText').textContent = `Your ${exam.trim()} feed is ready. Review the latest practice sets and updates curated for learners in ${location.trim()}.`;
}

function showGuestId(guestId) {
  if (!guestId) return;
  let guestLabel = document.querySelector('#guestUserId');
  if (!guestLabel) {
    guestLabel = document.createElement('p');
    guestLabel.id = 'guestUserId';
    guestLabel.className = 'muted';
    document.querySelector('#profileName')?.parentElement.appendChild(guestLabel);
  }
  guestLabel.textContent = `Guest ID: ${guestId}`;
}
document.querySelector('#editProfile')?.addEventListener('click', () => {
  document.querySelector('#settingsName').value = document.querySelector('#profileName').textContent;
  document.querySelector('#settingsExam').value = window.localStorage.getItem('preply-profile-exam') || 'SSC CGL';
  document.querySelector('#settingsLocation').value = window.localStorage.getItem('preply-profile-location') || 'India';
  document.querySelector('#settingsLearnerType').value = window.localStorage.getItem('preply-learner-type') || 'boy';
  document.querySelector('#settingsModal').classList.add('visible');
  document.querySelector('#settingsModal').setAttribute('aria-hidden', 'false');
});
const savedProfileName = window.localStorage.getItem('preply-profile-name');
const isAuthenticated = window.localStorage.getItem('preply-authenticated') === 'true';
if (isAuthenticated && savedProfileName) document.querySelector('#profileName').textContent = savedProfileName;
if (!isAuthenticated && document.querySelector('#profileName')) document.querySelector('#profileName').textContent = 'Your profile';
const savedExam = window.localStorage.getItem('preply-profile-exam');
const savedLocation = window.localStorage.getItem('preply-profile-location');
if (isAuthenticated && savedExam && savedLocation) saveProfileDetails(savedProfileName || '', savedExam, savedLocation);
document.querySelector('#settingsClose')?.addEventListener('click', () => { document.querySelector('#settingsModal').classList.remove('visible'); document.querySelector('#settingsModal').setAttribute('aria-hidden', 'true'); });
document.querySelector('#settingsForm')?.addEventListener('submit', (event) => { event.preventDefault(); saveProfileDetails(document.querySelector('#settingsName').value, document.querySelector('#settingsExam').value, document.querySelector('#settingsLocation').value, document.querySelector('#settingsLearnerType').value); document.querySelector('#settingsModal').classList.remove('visible'); document.querySelector('#settingsModal').setAttribute('aria-hidden', 'true'); });

const themeToggles = document.querySelectorAll('.theme-toggle');
function setTheme(theme) {
  const isDark = theme === 'dark';
  document.body.classList.toggle('dark-theme', isDark);
  themeToggles.forEach((toggle) => {
    toggle.setAttribute('aria-pressed', String(isDark));
    toggle.setAttribute('aria-label', isDark ? 'Switch to light theme' : 'Switch to dark theme');
  });
  window.localStorage.setItem('preply-theme', theme);
}
setTheme(window.localStorage.getItem('preply-theme') || 'light');
themeToggles.forEach((toggle) => toggle.addEventListener('click', () => setTheme(document.body.classList.contains('dark-theme') ? 'light' : 'dark')));

const learnerType = document.querySelector('#learnerType');
const learnerArt = document.querySelector('#learnerArt');
function setLearnerType(type) {
  learnerArt?.classList.remove('boy-art', 'girl-art', 'other-art');
  learnerArt?.classList.add(`${type}-art`);
  if (learnerType) learnerType.value = type;
  window.localStorage.setItem('preply-learner-type', type);
}
setLearnerType(window.localStorage.getItem('preply-learner-type') || 'boy');
learnerType?.addEventListener('change', (event) => setLearnerType(event.target.value));

const updateModal = document.querySelector('#updateModal');
if (updateModal && !window.localStorage.getItem('preply-updates-email')) {
  window.setTimeout(() => {
    updateModal.classList.add('visible');
    updateModal.setAttribute('aria-hidden', 'false');
  }, 1200);
}
function closeUpdateModal() {
  updateModal?.classList.remove('visible');
  updateModal?.setAttribute('aria-hidden', 'true');
}
document.querySelector('#updateClose')?.addEventListener('click', closeUpdateModal);
document.querySelector('#skipUpdates')?.addEventListener('click', closeUpdateModal);
document.querySelector('#updateForm')?.addEventListener('submit', (event) => { event.preventDefault(); window.localStorage.setItem('preply-updates-email', event.currentTarget.querySelector('input').value.trim()); document.querySelector('#updateSuccess').hidden = false; window.setTimeout(closeUpdateModal, 900); });

document.title = 'Result Darpan | Practice smarter. Score higher.';
document.querySelectorAll('.brand').forEach((brand) => {
  brand.setAttribute('aria-label', 'Result Darpan home');
  brand.innerHTML = '<span class="brand-mark">R</span><span>Result <span>Darpan</span></span>';
});
const brandTextWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
const brandTextNodes = [];
while (brandTextWalker.nextNode()) brandTextNodes.push(brandTextWalker.currentNode);
brandTextNodes.forEach((node) => {
  node.nodeValue = node.nodeValue.replace(/PrepLy|Preply|PREPLY/g, 'Result Darpan');
});

const chatForm = document.querySelector('#chatForm');
const chatInput = document.querySelector('#chatInput');
const chatMessages = document.querySelector('#chatMessages');
const chatLockNotice = document.querySelector('#chatLockNotice');
const chatLockKey = 'preply-chat-locked-until';
const abusiveWords = ['abuseword', 'idiot', 'stupid', 'shut up', ' hate ', 'kill yourself'];

function getChatLock() {
  const lockedUntil = Number(window.localStorage.getItem(chatLockKey) || 0);
  return lockedUntil > Date.now() ? lockedUntil : 0;
}

function applyChatLock(lockedUntil) {
  const locked = lockedUntil > Date.now();
  chatInput.disabled = locked;
  chatForm.querySelector('button').disabled = locked;
  chatInput.placeholder = locked ? 'Chat is paused for 7 days' : 'Ask a study question...';
  chatLockNotice.hidden = !locked;
  if (locked) {
    const days = Math.ceil((lockedUntil - Date.now()) / 86400000);
    chatLockNotice.textContent = `Chat access is paused for ${days} day${days === 1 ? '' : 's'} because our study space rules were broken. You can return when the pause ends.`;
  }
}

applyChatLock(getChatLock());
function appendLiveChatMessage(message) {
  const messageElement = document.createElement('div');
  const isStudent = message.author === 'student';
  messageElement.className = `chat-message ${isStudent ? 'student' : 'topper'}`;
  messageElement.innerHTML = isStudent
    ? '<div><b>You</b><p></p></div><span class="chat-avatar you-avatar">AS</span>'
    : '<span class="chat-avatar">MT</span><div><b>Mentor</b><p></p></div>';
  messageElement.querySelector('p').textContent = message.text;
  chatMessages.appendChild(messageElement);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

if (chatMessages) {
  const chatStream = new EventSource('/api/chat/stream');
  chatStream.addEventListener('message', (event) => appendLiveChatMessage(JSON.parse(event.data)));
  chatStream.addEventListener('profile-updated', (event) => {
    const update = JSON.parse(event.data);
    if (update.email === window.localStorage.getItem('preply-account-email')) updateProfileMetrics(update.stats);
  });
}

chatForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!message || getChatLock()) return;
  const normalized = ` ${message.toLowerCase()} `;

  if (abusiveWords.some((word) => normalized.includes(word))) {
    const lockedUntil = Date.now() + (7 * 86400000);
    window.localStorage.setItem(chatLockKey, String(lockedUntil));
    applyChatLock(lockedUntil);
    chatLockNotice.textContent = 'Chat access is paused for 7 days because abusive language was detected. Please keep the study room respectful.';
    return;
  }

  try {
    const response = await apiRequest('/api/chat/messages', {
      method: 'POST',
      body: JSON.stringify({ text: message, author: 'student' })
    });

    chatInput.value = '';
  } catch (error) {
    chatLockNotice.hidden = false;
    chatLockNotice.textContent = error.message;
  }
});
